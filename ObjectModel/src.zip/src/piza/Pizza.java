package piza;

public interface Pizza {
   int calculatePizza();

   int basePrice=60;
   
   Toppings toppings = new Toppings();

}
